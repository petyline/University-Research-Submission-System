from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from database import get_db
from models import Submission, User, ProposalTypeEnum
from auth_jwt import get_current_user
from utils_similarity import compute_similarity_percent
from utils_email import send_email

router = APIRouter()

# ✅ Define a Pydantic model for JSON input
class ProposalSubmission(BaseModel):
    student_id: int
    proposal_type: ProposalTypeEnum
    proposed_title: str
    background: str
    aim: str
    objectives: str
    methods: str
    expected_results: str
    literature_review: str

class ProposalUpdate(BaseModel):
    proposal_type: ProposalTypeEnum | None = None
    proposed_title: str | None = None
    background: str | None = None
    aim: str | None = None
    objectives: str | None = None
    methods: str | None = None
    expected_results: str | None = None
    literature_review: str | None = None

@router.post("/submit")
def submit_proposal(payload: ProposalSubmission, db: Session = Depends(get_db)):
    student = db.query(User).filter(User.id == payload.student_id, User.role == "student").first()
    if not student:
        raise HTTPException(status_code=404, detail="Student not found")
    if not student.supervisors or len(student.supervisors) == 0:
        raise HTTPException(status_code=400, detail="No supervisor assigned")

    # 🔹 Check existing proposals of same type
    existing = db.query(Submission).filter(Submission.proposal_type == payload.proposal_type).all()
    existing_texts = [
        " ".join(
            filter(None, [e.background, e.aim, e.objectives, e.methods, e.literature_review])
        )
        for e in existing
    ]

    new_text = " ".join(
        filter(
            None,
            [
                payload.background,
                payload.aim,
                payload.objectives,
                payload.methods,
                payload.literature_review,
            ],
        )
    )
    similarity = compute_similarity_percent(new_text, existing_texts)
    supervisor = student.supervisors[0]

    submission = Submission(
        student_id=student.id,
        supervisor_id=supervisor.id,
        proposal_type=payload.proposal_type,
        proposed_title=payload.proposed_title,
        background=payload.background,
        aim=payload.aim,
        objectives=payload.objectives,
        methods=payload.methods,
        expected_results=payload.expected_results,
        literature_review=payload.literature_review,
        similarity_score=similarity,
    )
    db.add(submission)
    db.commit()
    db.refresh(submission)

    # 🔹 Send notification emails
    subj_student = "Submission received"
    body_student = (
        f"<p>Dear {student.name},</p>"
        f"<p>Your {payload.proposal_type} submission was received. "
        f"Similarity: <b>{similarity}%</b>.</p>"
    )
    send_email(student.email, subj_student, body_student)

    subj_sup = f"New submission from {student.reg_number or student.email}"
    warn = '<p style="color:red"><b>⚠️ High similarity detected</b></p>' if similarity >= 70 else ""
    body_sup = (
        f"<p>Dear {supervisor.name},</p>"
        f"<p>Student <b>{student.name} ({student.reg_number})</b> submitted a {payload.proposal_type}.</p>"
        f"<p>Similarity: <b>{similarity}%</b>.</p>{warn}<p>Please log in to review.</p>"
    )
    send_email(supervisor.email, subj_sup, body_sup)

    return {"id": submission.id, "similarity": similarity, "warning": similarity >= 70}


@router.put("/update_submission/{submission_id}")
def update_submission(
    submission_id: int,
    payload: ProposalUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """🔹 Securely update a submission"""

    submission = db.query(Submission).filter(Submission.id == submission_id).first()
    if not submission:
        raise HTTPException(status_code=404, detail="Submission not found")

    # 🔹 Authorization: Only allow the owning student, or optionally admin/lecturer
    if current_user.role == "student" and submission.student_id != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to update this submission")
    if current_user.role == "lecturer":
        # Lecturers can only update submissions of their supervised students
        student = db.query(User).filter(User.id == submission.student_id).first()
        if not student or current_user not in student.supervisors:
            raise HTTPException(status_code=403, detail="Not authorized to update this submission")
    # Admins can update any submission

    # 🔹 Update fields if provided
    for field, value in payload.dict(exclude_unset=True).items():
        setattr(submission, field, value)

    # 🔹 Recalculate similarity if any content fields changed
    content_fields = ["background", "aim", "objectives", "methods", "literature_review"]
    if any(f in payload.dict(exclude_unset=True) for f in content_fields):
        existing = db.query(Submission).filter(
            Submission.proposal_type == submission.proposal_type,
            Submission.id != submission.id
        ).all()
        existing_texts = [
            " ".join(filter(None, [e.background, e.aim, e.objectives, e.methods, e.literature_review]))
            for e in existing
        ]
        new_text = " ".join(filter(None, [
            submission.background,
            submission.aim,
            submission.objectives,
            submission.methods,
            submission.literature_review,
        ]))
        submission.similarity_score = compute_similarity_percent(new_text, existing_texts)

    db.commit()
    db.refresh(submission)

    return {
        "id": submission.id,
        "similarity": submission.similarity_score,
        "message": "Submission updated successfully"
    }



@router.get("/student_submissions/{student_id}")
def get_student_submissions(student_id: int, db: Session = Depends(get_db)):
    submissions = (
        db.query(Submission)
        .filter(Submission.student_id == student_id)
        .order_by(Submission.created_at.desc())
        .all()
    )
    return submissions


@router.get("/submission/{student_id}")
def get_latest_submission(student_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    sub = (
        db.query(Submission)
        .filter(Submission.student_id == student_id)
        .order_by(Submission.created_at.desc())
        .first()
    )
    if not sub:
        raise HTTPException(status_code=404, detail="Submission not found")

    if current_user.role == "student" and current_user.id == student_id:
        return sub
    if current_user.role == "lecturer":
        student = db.query(User).filter(User.id == student_id).first()
        if student and current_user in student.supervisors:
            return sub
    if current_user.role == "admin":
        return sub

    raise HTTPException(status_code=403, detail="Not authorized")
